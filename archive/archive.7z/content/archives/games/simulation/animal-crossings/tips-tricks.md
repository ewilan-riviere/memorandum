---
title: Tips & tricks
description: ''
position: 1
category: 'Animal Crossings'
---

Cette section concerne le jeu Animal Crossings: New Horizons sur Nintendo Switch

## Astuces

- Faire porter ses motifs à ses habitants : remplacer les vêtements au fond de l'atelier de couture par ses propres motifs et après quelques temps les habitants vont porter ces motifs
- Avoir des motifs supplémentaires : parler pendant une semaine à Cousette tous les jours pour qu'elle finisse par débloquer des catégories de motifs supplémentaires, elle offrira des nouveaux motifs tous les jours
- Se lier d'amitié avec ses habitants : TODO
- Des objets rares : en-dehors de la boutique, les objets rares peuvent se trouver dans les cadeaux liés aux ballons, en secouant les arbres ou sur les îles mystère
  - Il est à noter que les habitants offrent en retour des cadeaux qui leur sont faits, des cadeaux d'une valeur plus ou moins égale. Les pousses de bambous sont considérées comme très rares et donc, de ce fait, le cadeau qu'ils offriront en retour sera assez rare
- Gagner beaucoup de Clochettes : les navets sont le meilleur plan à long terme pour gagner beaucoup de Clochettes
  - Consulter la liste des îles disponibles sur [**turnip.exchange**](https://turnip.exchange/) TODO abo
  - Prévoir son taux de revente [**ac-turnip.com**](https://ac-turnip.com/)

- <https://www.youtube.com/watch?v=mh3-2erfpP0&t=1s>
- <https://www.youtube.com/watch?v=zAemD7adk-s>
- <https://www.pinterest.fr/whatsupclaire/inspiration-animal-crossing-new-horizons/>? invite_code=af453b4592d1432ab8bc44423b8219b4&sender=350788395884123977  
- <https://www.breakflip.com/fr/animal-crossing-new-horizons/guide/> animal-crossing-new-horizons-fleurs-hybrides-tous-les-croisements-19275  
- <https://margxt.fr/guide-les-fleurs-hybrides-dans-animal-crossing-new-horizons/#multiplier-les-hybrides>  
- <https://www.breakflip.com/fr/animal-crossing-new-horizons/guide/comment-voir-des-etoiles-filantes-dans-animal-crossing-new-horizons-et-obtenir-des-fragments-d-etoiles-19226>  
