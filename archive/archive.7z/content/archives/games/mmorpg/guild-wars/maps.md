---
title: Maps
description: ''
position: 1
category: 'Guild Wars'
---

[**Wiki**](https://wiki.guildwars.com/wiki/List_of_maps)

## Tyria

<guild-wars-map source="/images/games/guild-wars/tyria-high-resolution.jpg" />

## Cantha

<guild-wars-map source="/images/games/guild-wars/cantha-high-resolution.jpg" />

## Elona

<guild-wars-map source="/images/games/guild-wars/elona-high-resolution.jpg" />

## Eye of the North

<guild-wars-map source="/images/games/guild-wars/eye-of-the-north.jpg" />
