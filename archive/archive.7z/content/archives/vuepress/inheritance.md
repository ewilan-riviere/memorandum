---
title: Inheritance
description: ''
position: 1
category: 'Vuepress'
---

# Inheritance

TODO

- <https://v1.vuepress.vuejs.org/guide/i18n.html#default-theme-i18n-config>
- <https://vuepress.vuejs.org/plugin/official/plugin-last-updated.html#options>
- <https://vuepress.vuejs.org/theme/inheritance.html#override-components>
- <https://vuepress-examples.netlify.app/demos/extending/#what-s-in-the-default-theme>
- <https://stackoverflow.com/questions/57172350/vuepress-theme-inheritance-setup>
