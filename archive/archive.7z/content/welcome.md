---
title: Introduction
description: ''
position: 1
category: ''
features:
  - Full markdown documentation
  - Powered by NuxtJS & nuxt/content
  - Examples, boiler plates, snippets
  - Built to be extensible
---

<!-- ## Features -->

<md-list :items="features"></md-list>

I'm Web developer since 2018, I learn a lot about some different languages, frameworks, techs... And I needed to have some place to get more than snippets. I wanted to can write some article about concepts, with boiler plates and explications. But I would to have a beautiful interface and user friendly blocks of codes, easy to copy.

It's not really a documentation or a blog, it's curious mix between two. I update it regulary but I advice you to use information with caution, these can be not up to date.

**Ewilan Rivière**
