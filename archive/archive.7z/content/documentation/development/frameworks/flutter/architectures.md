---
title: Architectures
description: 'Choose an architecture for Flutter project'
position: 10
---

- [New Setup for Flutter Stacked State Management](https://www.filledstacks.com/post/new-setup-for-flutter-stacked-state-management/)
- [github.com/FilledStacks/stacked](https://github.com/FilledStacks/stacked)
- [Advanced Flutter Dialogs](https://www.filledstacks.com/)
