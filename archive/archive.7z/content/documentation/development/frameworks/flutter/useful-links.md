---
title: Useful links
description: 'Links about Flutter concepts'
position: 14
category: 'Flutter'
---

- [**Android Asset Studio**](https://romannurik.github.io/AndroidAssetStudio/index.html): design icons for your application
- Flutter BLoC
  - [**Reactive programming - Streams - BLoC**](https://www.didierboelens.com/fr/2018/08/reactive-programming-streams-bloc)
  - [**Reactive programming - Streams - BLoC - Cas pratiques d'utilisation**](https://www.didierboelens.com/fr/2018/12/reactive-programming-streams-bloc-cas-practiques-dutilisation)
  - [**BLoC - ScopedModel - Redux**](https://www.didierboelens.com/fr/2019/04/bloc-scopedmodel-redux-comparaison)
