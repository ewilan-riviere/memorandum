---
title: Extensions
description: 'Extensions'
position: 6
category: 'Tailwind CSS'
---

## Visual Studio Code

- [**Tailwind CSS IntelliSense**](https://marketplace.visualstudio.com/items?itemName=bradlc.vscode-tailwindcss)
- [**Headwind**](https://marketplace.visualstudio.com/items?itemName=heybourn.headwind)
- [**Tailwind Shades**](https://marketplace.visualstudio.com/items?itemName=bourhaouta.tailwindshades)

## Browser

- [**Windy**](https://beyondco.de/licenses/windy): to copy what you see on any website and convert it to Tailwind CSS code

## Misc

- [**Tint**](https://beyondco.de/software/tint) : an OS extension to pick color on any website and convert it to Tailwind CSS palette
