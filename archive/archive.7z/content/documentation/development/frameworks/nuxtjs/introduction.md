---
title: Introduction
description: 'Build your next Vue.js application with confidence using NuxtJS. An open source framework making web development simple and powerful.'
position: 1
category: 'NuxtJS'
---

- [**nuxtjs.org**](https://nuxtjs.org/) : official NuxtJS documentation
- [**modules.nuxtjs.org**](https://modules.nuxtjs.org) : list of official NuxtJS modules
