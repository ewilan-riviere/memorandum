---
title: Tutorials
description: 'Some tutorials'
position: 9
category: 'Laravel'
---

- [**Laravel 8 Database Seeders, Fakers, and Factories**](https://medium.com/dev-genius/laravel-8-x-database-seeders-fakers-and-factories-7cb759918124) by Dino Cajic, 16/10/2020 (7 min to read)
- [**Setting up Laravel 8 with JetStream Auth**](https://medium.com/dev-genius/setting-up-laravel-8-x-with-jetstream-auth-84bbeafc0cd3) by Dino Cajic, 19/10/2020 (8 min to read)
