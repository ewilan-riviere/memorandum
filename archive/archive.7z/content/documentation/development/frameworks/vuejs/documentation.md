---
title: Documentation
description: ''
position: 4
category: 'Vue.js'
---

## IDE Autocompletion

- <https://vue-styleguidist.github.io/>
- <https://github.com/vuejs/vetur/issues/1337>
- <https://vuejs.github.io/vetur/component-data.html#workspace-component-data>
