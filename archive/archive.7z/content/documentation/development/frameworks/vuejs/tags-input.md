---
title: Tags input
description: ''
position: 4
category: 'Vue.js'
---

## Packages

- <https://github.com/JohMun/vue-tags-input>
- <https://github.com/shentao/vue-multiselect>
- <https://github.com/voerro/vue-tagsinput>

## Example

- <https://learnvue.co/2020/01/build-a-custom-vuejs-tag-input-in-under-10-minutes/>
