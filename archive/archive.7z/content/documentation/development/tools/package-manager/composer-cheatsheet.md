---
title: Composer cheatsheet
description: 'Useful commands for Composer'
position: 3
category: 'Package manager'
---

## Switch between Composer version

```bash
composer self-update --1
```

```bash
composer self-update --2
```
