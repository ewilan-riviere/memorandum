---
title: Tips & tricks
description: 'Tips with Dart so on Flutter'
position: 1
category: 'Dart'
---

```dart
String boolAsString = 'true';
bool myBool = boolAsString == 'true';

if(myBool) {
  // do stuff
}
```
