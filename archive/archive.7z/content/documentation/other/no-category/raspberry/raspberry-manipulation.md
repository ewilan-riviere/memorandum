---
title: Keymap
description: ''
position: 1
category: 'Raspberry'
---

# 📺 Raspberry: manipulation

## 1. HDMI index

For *Sony Bravia* television.

- **1** :
- **2** : *Switch*
- **3** : *Chromecast*
- **4** : *Raspberry*

## 2. Raspberry usage

With portable keyboard...
