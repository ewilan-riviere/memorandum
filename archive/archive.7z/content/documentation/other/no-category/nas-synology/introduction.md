---
title: Introduction
description: ''
position: 1
category: 'NAS Synology'
---

# Welcome

## Box & routeur

<https://le-routeur-wifi.com/comment-brancher-routeur-derriere-box-internet/>
<https://blog.e-nnov.fr/synology-dsm/dhcp/>
<https://waytolearnx.com/2018/07/difference-entre-un-switch-et-un-routeur.html>
