---
title: "About VPS"
description: 'What is a VPS'
position: 1
category: 'vps'
---

A **VPS** is a Virtual private server, in other words a distant server that any hosting society rent to you for a monthly price. You can access to it with SSH and it's your server and you can do everything you want with it, when you buy a subscription you can often choose operating sytem like Ubuntu, Debian, BSD... Some society don't let you choose and some other society offer many possibilities. On this market, you can have many different prices, for an example, I have a VPS on Digital Ocean for 10$/mo (and minimal price is 5$/mo), I have Debian distrib on it with 2GB RAM, 1 vCPU and 50GB Disk. I can easily resize my VPS to get more resources if I need it.

When you build an web application, you need to deploy it one day and for this, you need to have a VPS and a domain. You can buy a domain from registrar, I use porkbun but you can choose a big registrar like OVH.

// TODO list of vps offers, list of registrars, other services like mutual server
