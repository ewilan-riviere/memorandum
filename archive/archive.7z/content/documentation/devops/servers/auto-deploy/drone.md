---
title: Drone CI
description: 'Auto deploy your work with Drone'
position: 2
category: 'auto-deploy'
---

- <https://www.drone.io>
- <https://github.com/drone-runners/drone-runner-exec>
- <https://linuxize.com/post/how-to-remove-docker-images-containers-volumes-and-networks/>
- setup
  - <https://www.digitalocean.com/community/tutorials/how-to-install-and-configure-drone-on-ubuntu-20-04>
  - <https://www.vultr.com/docs/how-to-install-drone-ci-on-ubuntu-18-04>
  - <https://eriksamuelsson.com/how-to-install-and-configure-drone-ci-on-a-self-hosted-server/>
  - <https://ubuntu.com/blog/continuous-integration-with-juju-and-drone-ci>
  - <https://docs.drone.io/cli/install/>
- provider webhook : <https://docs.drone.io/server/provider/github/>

Docker

- <https://www.digitalocean.com/community/tutorials/how-to-install-and-use-docker-on-ubuntu-20-04>
- <https://linuxhint.com/install_configure_docker_ubuntu/>
- <https://grigorkh.medium.com/how-to-install-docker-on-ubuntu-20-04-f1b99845959e>
