---
title: Seeds
description: ''
position: 2
category: 'Oxygen Not Included'
---

## Reboot

### Rime asteroid

[*S-FRZ-11117-0*](https://toolsnotincluded.net/map-tools/map-browser/map/261366)
