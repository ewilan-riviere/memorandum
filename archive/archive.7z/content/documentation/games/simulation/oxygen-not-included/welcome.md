---
title: Welcome
description: ''
position: 1
category: 'Oxygen Not Included'
---

## Asteroids seeds

[toolsnotincluded.net](https://toolsnotincluded.net/)

## Game database

[oni-db.com](http://www.oni-db.com/)

## Geyser calculator

[onical.ga](https://onical.ga/)

## Heat transfer calculator

[oni-heat-calc.cba.pl](http://www.oni-heat-calc.cba.pl/)

## Rocket simulator

[oni-assistant.herokuapp.com](https://oni-assistant.herokuapp.com/)

## Blueprints

[blueprints-not-included.com](https://blueprints-not-included.com/)  
[blueprintnotincluded.com](http://blueprintnotincluded.com/)  
[oniarchitecte.com](https://www.oniarchitecte.com)

## Save editor

[robophred.github.io/oni-duplicity/](https://robophred.github.io/oni-duplicity/#/)
